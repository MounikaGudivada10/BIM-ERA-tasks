#20. Check smart home security system
door = input("closed door: ")
camera = input("Active Camera: ")
alarm = input("Alarm Enabled : ")
if door == "yes" and camera == "yes" and alarm == "yes":
     print("Home Secure")
else:
     print("Security Warning")