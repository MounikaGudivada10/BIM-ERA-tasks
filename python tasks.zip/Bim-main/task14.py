#14. Check weather alert system
temperature = int(input())
wind = int(input())
rain = input()
if temperature > 40 and wind > 50 and rain == "no":
     print("Heat Alert")
elif rain == "yes" and wind > 60:
     print("Storm Alert")
else:
     print("Normal Weather")