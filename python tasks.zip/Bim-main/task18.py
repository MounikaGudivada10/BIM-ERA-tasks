#18. Check laptop purchase recommendation
budget = int(input("budget : "))
ram = int(input("RAM: "))
storage = int(input("storage : "))
if budget > 100000 and ram >= 16 and storage >= 512:
     print("Gaming Laptop")
elif budget > 50000 and ram >= 8:
     print("Office Laptop")
else:
     print("Basic Laptop")