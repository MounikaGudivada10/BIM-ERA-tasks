#30. Check whether marks are not passing marks
passm = int(input("enter the marks: "))
if not (passm >= 35):
    print("marks are not passing marks")
else:
    print("marks are passing marks")
