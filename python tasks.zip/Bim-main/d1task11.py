#11. Check whether entered role is Admin or Manager
role=input("enter role: ")
if role=="admin" or role=="manager":
    print("access granted")
else:
    print("acces denied")