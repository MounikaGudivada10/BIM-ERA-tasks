#4. Check internet package category
speed=int(input("enter speed: "))
data =int(input("enter data usage: "))
rem_days=int(input("enter rem_days: "))
if speed>100 and data>500 and rem_days>20:
    print("premium plan")
elif speed>50 and data>200:
    print("standard plan")
else:
    print("basic plan")