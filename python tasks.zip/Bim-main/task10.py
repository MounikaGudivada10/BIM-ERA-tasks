#10. Check exam topper category
sub1=int(input("enter ur sub1 marks:"))
sub2=int(input("enter ur sub2 marks:"))
sub3=int(input("enter ur sub3 marks:"))
total=sub1+sub2+sub3
if total>=270:
    print("topper")
elif total>=180:
    print("average")
else:
    print("needs improvement")