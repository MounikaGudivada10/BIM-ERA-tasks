#27. Check whether password is not correct
password=input("enter ur password:")
if not(password == "anjali"):
    print("u have entered wrong password")
else:
    print("u can login")
