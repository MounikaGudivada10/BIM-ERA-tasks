#2. Check student distinction category
maths=int(input("enter maths marks:"))
english=int(input("enter english marks:"))
science=int(input("enter science marks:"))
if maths>=75 and english>=75 and science>=75:
    print("destinction")
elif maths>=35 and english>=35 and science>=35:
    print("pass")
else:
    print("fail")