#5. Check whether temperature is within safe range
temp=int(input("enter temperature: "))
hightemp=35;lowtemp=16
if temp>lowtemp and temp<hightemp:
    print("u r in safe range")
else:
    print("u r in bad temperature")