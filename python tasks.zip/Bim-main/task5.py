#5. Check job eligibility
experience=int(input("enter experience:"))
age=int(input("enter age:"))
degree=input("enter degree:")
if degree=="yes" and age>21 and experience>=2:
    print("eligible for the interview")
else:
    print("not eligible")