#17. Check sports team selection
speed = int(input("Speed Score : "))
fitness = int(input("Fitness Score : "))
discipline = int(input("Discipline Score : "))
if speed > 80 and fitness > 80 and discipline > 80:
     print("Selected")
elif speed > 60 and fitness > 60:
     print("Waiting List")
else:
     print("Rejected")