#24. Check whether file is not available
file=input("is file available:")
if not (file == "True"):
    print("file is NOT available")
else:
    print("file is  available")