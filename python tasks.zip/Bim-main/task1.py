#1.Check Employee promotion eligibility
age=int(input("enter age:"))
salary=int(input("enter salary:"))
experience=int(input("enter experience:"))
if age>=25 and salary>=50000 and experience>5:
    print(" eligible for promotion")
else:
    print("not eligible")