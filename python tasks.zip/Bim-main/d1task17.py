#17. Check whether entered username matches predefined values
username=input("enter a name:")
if username=="anjali" or username=="sowmya" or username=="poojitha":
    print("u can login")
else:
    print("u cannot login")