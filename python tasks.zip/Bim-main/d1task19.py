#19. Check whether entered city matches allowed cities
city=input("enter a city:")

if city=="hyd" or city=="vizag" or city=="manali":
    print(f"{city} is allowed")
else:
    print(f"{city} doesnt match")