#15. Check online shopping offer
amount=int(input("enter  amount:"))
coupon=input("is coupon available:")
premium_mem=input("is premium-membership available:")
if amount>10000 and coupon=="yes" and premium_mem=="yes":
    print("maximum discount")
elif amount>5000 and coupon=="yes":
    print("minimum discount")
else:
    print("no discount")