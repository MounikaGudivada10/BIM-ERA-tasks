#6. Check flight boarding eligibility
ticket=input("is ticket available:")
passport=input("is passport available:")
luggage_weight=int(input("enter your luggage weight:"))
if ticket=="yes" and passport=="yes" and luggage_weight<=30:
    print(" boarding allowed")
else:
    print("boarding denied")
