#26. Check whether project status is not completed
project=int(input("enter the project status:"))
if not(project >=80):
    print("project is not completed")
else:
    print("project is near to complition")