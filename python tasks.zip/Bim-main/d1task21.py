#21. Check whether user is not admin
usr=input("enter user:")
if not usr =="admin":
    print("user is not admin")
else:
    print("user is admin")