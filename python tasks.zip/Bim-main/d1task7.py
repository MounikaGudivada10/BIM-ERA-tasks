#7. Check whether both entered numbers are positive
p=3
l=5
if p>=0 and l>=0:
    print("its a positive num")
else:
    print("its not a positive num")