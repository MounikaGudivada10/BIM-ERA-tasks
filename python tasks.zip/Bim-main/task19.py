#19. Check bank loan approval
salary = int(input("salary: "))
creditscore = int(input("Score : "))
experience = int(input("Experience : "))
if salary > 50000 and creditscore > 750 and experience > 3:
     print("Loan Approved")
elif salary > 30000 and creditscore > 650:
     print("Loan Under Review")
else:
     print("Loan Rejected")
