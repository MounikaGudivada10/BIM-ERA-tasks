#13. Check movie ticket pricing
age = int(input("Enter Age : "))
day = input("Enter Day : ")
member = input("Membership Available : ")
if age<18 and member=="yes" and day=="Sunday":
    print("50% Discount")
elif member=="yes":
    print("25% Discount")
else:
    print("No Discount")
 