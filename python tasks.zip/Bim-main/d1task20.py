#20. Check whether entered number matches predefined values
num=int(input("enter a num:"))
n=[16,17,31,12]
if num in n:
    print(f"{num} matches n values")
else:
    print("doeswnt match")