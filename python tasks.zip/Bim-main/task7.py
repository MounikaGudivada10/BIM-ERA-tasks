#7. Check scholarship eligibility
marks=int(input("enter ur marks:"))
attendence=int(input("enter ur attendence:"))
income=int(input("enter ur family_income:"))
if marks>=85 and attendence>=90 and income<300000:
    print("scholarship approved")
else:
    print("Scholarship Rejected")