#8. Check whether person is eligible for driving
age=int(input("enter age: "));l=input("is license available: ")
if age>=21 and l=="yes":
    print("he is eligible for driving")
else:
    print("not eligible")
    

