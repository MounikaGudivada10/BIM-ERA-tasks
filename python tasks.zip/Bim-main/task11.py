#11. Check gym membership category
age=int(input("enter ur age:"))
weight=int(input("enter ur weight :"))
height=float(input("enter ur height:"))
if age>18 and weight>50 and height>5.5:
    print("fitness category A")
elif weight>40 and height>5:
    print("fitness category B")
else:
    print("basic category")