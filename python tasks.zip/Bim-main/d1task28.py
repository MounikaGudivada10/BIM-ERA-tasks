#28. Check whether temperature is not safe
temp=int(input("enter the current temperature: "))
if not (temp >= 45):
    print("ur in safe zone")
else:
    print("ur not in safe temperature")