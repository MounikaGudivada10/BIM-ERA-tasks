#3. Check whether entered value is between two ranges
value=int(input("enter a num:"))
max_value=50
min_value=10
if value>min_value and value<max_value:
    print("entered within limit")
else:
    print("enter proper value")