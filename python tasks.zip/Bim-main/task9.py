#9. Check hotel booking eligibility
rooms=int(input("enter no of rooms:"))
days=int(input("enter no of days:"))
budget=int(input("enter the budget:"))
if rooms>=2 and days>=3 and budget>50000:
    print("luxury booking")
elif rooms>=1 and days>=2 and budget>=30000:
    print("standard booking")
else:
    print("budget booking")
