#25. Check whether employee is not active
emp=input("is employee is active:")
if not (emp== "True"):
    print("employee is not active")
else:
    print("employee is active")