#15. Check whether salary or experience satisfies requirement
salary=int(input("enter ur salary:"))
experience=input("enter ur experience:")
if salary>=30000 or experience>="3 yrs":
    print("u can satisfy our requirement")
else:
    print("better luck next time")
