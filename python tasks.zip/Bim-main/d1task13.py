#13. Check whether entered day is weekend
week=input("enter a day:")
if week=="saturday" or week=="sunday":
    print("u entered a weekend day")
else:
    print(" u enterted a wrong day") 