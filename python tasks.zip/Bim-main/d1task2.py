#2. Check whether student passed in two subjects
a=int(input("enter sub1 marks:"))
b=int(input("enter sub2 marks:"))
if a>=35 and b>=35:
    print("the student passed the exam")
else:
    print("student failed in both the exams")