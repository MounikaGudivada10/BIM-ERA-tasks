#6. Check whether both entered numbers are even
a=5
b=6
if a%2==0 and b%2==0:
    print("its even num")
else:
    print("its not a even num")