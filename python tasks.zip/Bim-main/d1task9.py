#9. Check whether project progress meets deadline condition
rem_days=int(input("enter remaining days:"))
progress=int(input("enter progress:"))
if rem_days>=5 and progress>=80:
    print("ur not in deadline condition")
else:
    print("ur in deadline condition")