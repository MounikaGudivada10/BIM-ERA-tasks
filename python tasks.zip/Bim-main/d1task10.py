#10. Check whether attendance and marks satisfy eligibility
attendence=int(input("enter the attendence percentage: "))
marks=int(input("enter marks: "))
if attendence>=75 and marks>=65:
    print("can promote to next class")
else:
    print("detained")
    