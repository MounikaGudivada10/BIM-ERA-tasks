#14. Check whether selected category matches two possible values
category=input("enter ur category:")
if category=="IT" or category=="CSE":
    print("u come under software category")
else:
    print("u doesnt come into any category")