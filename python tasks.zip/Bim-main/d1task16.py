#16. Check whether temperature is extremely low or high
temp=int(input("enter temperature:"))
lower=16
upper=32
if temp<lower or temp>upper:
    print("temperature is extreme")
else:
    print("temperature is nrml")