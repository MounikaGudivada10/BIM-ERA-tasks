#29. Check whether selected option is not allowed
var=input("enter one of the option: ")
var1=["CSE","IT","EEE","ECE"]
if not (var in var1):
    print("u entered wrong option")
else:
    print("welcome to department")