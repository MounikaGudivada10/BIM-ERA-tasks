#23. Check whether entered value is not empty
value = input("enter value: ")
if not (value == ""):
    print("its  not empty")
else:
    ("string is  empty")