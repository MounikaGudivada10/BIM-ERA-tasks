#8. Check mobile unlock system
pin = int(input("Enter PIN : "))
face = input("Face Detected : ")
fingerprint = input("Fingerprint Verified : ")
if pin == 7499 and face == "yes" and fingerprint == "yes":
    print("Mobile Unlocked")
else:
    print("Access Denied")
