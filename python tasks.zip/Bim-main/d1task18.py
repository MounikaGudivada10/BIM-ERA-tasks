#18. Check whether selected option belongs to given choices
var=input("enter a fruit name:")
var1=["apple","banana","mango"]
if var in var1:
    print(f" {var} is available in above options")
else:
    print(f" {var} is not available")