#12. Check traffic penalty system
helmet=input("is helmet is there:")
license=input("is license is there:")
speed=int(input("enter speed:"))
if helmet=="yes"and license=="yes" and speed<80:
    print("no fine")
elif  speed>100:
    print("heavy fine")
else:
    print("fine")
