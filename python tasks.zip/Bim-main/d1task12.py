#11. Check whether entered role is Admin or Manager
english=int(input("enter eng marks:"))
maths=int(input("enter maths marks:"))
physics=int(input("enter phy marks:"))
if english>=75 or maths>=75 or physics>=75:
    print("passed in distinction")
else:
    print("failed")