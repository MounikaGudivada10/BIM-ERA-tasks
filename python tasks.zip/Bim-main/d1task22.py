#22. Check whether entered number is not positive
num=int(input("enter a num:"))
if not num >=0:
    print("its is  positive")
else:
    print("not a positive num")