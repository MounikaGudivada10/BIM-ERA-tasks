#16. Check server room access
idcard = input()
fingerprint = input()
accesslevel = int(input())
if idcard == "yes" and fingerprint == "yes" and accesslevel > 5:
     print("Access Granted")
else:
     print("Access Restricted")