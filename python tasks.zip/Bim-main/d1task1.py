#1. Check whether employee age is above 21 and salary is above 30000
age=int(input("enter age: "))
salary=int(input("enter salary: "))

if age >= 21 and salary >= 30000:
    print("employee is promoted")
else:
    print("still working as low-level employee")