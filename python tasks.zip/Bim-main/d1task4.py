#4. Check whether username and password are correct
a="anjali"
b=234
c=input("enter username: ")
d=int(input("enter password: "))
if a==c and b==d:
    print("user can login")
else:
    print("not accepted")