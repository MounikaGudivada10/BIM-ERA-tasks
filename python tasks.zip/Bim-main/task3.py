#3. Check website login system
username=input("enter username:")
password=input("enter password:")
otp=int(input("enter otp:"))

if username=="anjali" and password=="anju" and otp==1234:
    print("login successfull")
else:
    print("invalid")